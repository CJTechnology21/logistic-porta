export default ({ config }) => ({
  ...config,

  updates: {
    url: "https://u.expo.dev/e31119de-8260-4772-9009-3797a3a3e06a",
    enabled: false,
  },

  runtimeVersion: {
    policy: "appVersion",
  },

  extra: {
    ...config.extra,
    SUPABASE_URL: process.env.EXPO_PUBLIC_SUPABASE_URL,
    SUPABASE_ANON_KEY: process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY,
  },
});
