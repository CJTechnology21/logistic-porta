// Shifts management page
import React, { useEffect, useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/app/components/ui/card';
import { Badge } from '@/app/components/ui/badge';
import { Button } from '@/app/components/ui/button';
import { Input } from '@/app/components/ui/input';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/app/components/ui/table';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogHeader, AlertDialogTitle } from '@/app/components/ui/alert-dialog';
import { Search, Plus, Eye, CheckCircle, XCircle, Clock, Loader } from 'lucide-react';
import { format } from 'date-fns';
import { listShifts, listActiveShifts, endShift, Shift, countActiveShifts, countTodayShifts } from '@/lib/db/shifts';

export function ShiftsPage() {
  const [searchQuery, setSearchQuery] = useState('');
  const [shifts, setShifts] = useState<Shift[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [filterStatus, setFilterStatus] = useState<'all' | 'active' | 'completed'>('all');
  const [activeCount, setActiveCount] = useState(0);
  const [todayCount, setTodayCount] = useState(0);
  const [selectedShift, setSelectedShift] = useState<Shift | null>(null);
  const [endShiftDialog, setEndShiftDialog] = useState(false);

  // Fetch shifts on mount
  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        const [shiftsList, active, today] = await Promise.all([
          listShifts(),
          countActiveShifts(),
          countTodayShifts(),
        ]);
        setShifts(shiftsList);
        setActiveCount(active);
        setTodayCount(today);
        setError(null);
      } catch (err) {
        setError('Failed to load shifts');
        console.error(err);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  const filteredShifts = shifts.filter((shift) => {
    const matchesSearch =
      shift.driver_name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      shift.vehicle_plate.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesStatus = filterStatus === 'all' || shift.status === filterStatus;

    return matchesSearch && matchesStatus;
  });

  const handleEndShift = async () => {
    if (!selectedShift) return;

    try {
      await endShift(selectedShift.id);
      setShifts(
        shifts.map((s) =>
          s.id === selectedShift.id
            ? { ...s, status: 'completed', endTime: new Date().toISOString() }
            : s
        )
      );
      setActiveCount(Math.max(0, activeCount - 1));
      setEndShiftDialog(false);
      setSelectedShift(null);
      setError(null);
    } catch (err) {
      setError('Failed to end shift');
      console.error(err);
    }
  };

  return (
    <div className="space-y-6">
      {/* Error message */}
      {error && (
        <Card className="bg-red-950 border-red-900">
          <CardContent className="p-4 text-red-400">{error}</CardContent>
        </Card>
      )}

      {/* Page header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-white mb-2">Shifts</h1>
          <p className="text-gray-400">Track driver shifts and checklists</p>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <Card className="bg-[#161616] border-gray-800">
          <CardContent className="p-6">
            <p className="text-sm text-gray-400 mb-1">Active Shifts</p>
            <p className="text-3xl font-bold text-green-400">{loading ? '-' : activeCount}</p>
          </CardContent>
        </Card>
        <Card className="bg-[#161616] border-gray-800">
          <CardContent className="p-6">
            <p className="text-sm text-gray-400 mb-1">Today's Shifts</p>
            <p className="text-3xl font-bold text-white">{loading ? '-' : todayCount}</p>
          </CardContent>
        </Card>
        <Card className="bg-[#161616] border-gray-800">
          <CardContent className="p-6">
            <p className="text-sm text-gray-400 mb-1">Total Shifts</p>
            <p className="text-3xl font-bold text-blue-400">{loading ? '-' : shifts.length}</p>
          </CardContent>
        </Card>
      </div>

      {/* Shifts table */}
      <Card className="bg-[#161616] border-gray-800">
        <CardHeader>
          <div className="flex flex-col gap-4">
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
              <div>
                <CardTitle className="text-white">All Shifts</CardTitle>
                <CardDescription className="text-gray-400">
                  View shift history and current shifts
                </CardDescription>
              </div>
              <div className="relative w-full sm:w-64">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
                <Input
                  type="search"
                  placeholder="Search shifts..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10 bg-[#0F0F0F] border-gray-700 text-white placeholder:text-gray-500"
                />
              </div>
            </div>
            <div className="flex gap-2">
              <Button
                variant={filterStatus === 'all' ? 'default' : 'outline'}
                onClick={() => setFilterStatus('all')}
                className={
                  filterStatus === 'all'
                    ? 'bg-[#FF6B35] hover:bg-[#E55A2B] text-white'
                    : 'border-gray-700 text-gray-400 hover:text-white'
                }
              >
                All
              </Button>
              <Button
                variant={filterStatus === 'active' ? 'default' : 'outline'}
                onClick={() => setFilterStatus('active')}
                className={
                  filterStatus === 'active'
                    ? 'bg-[#FF6B35] hover:bg-[#E55A2B] text-white'
                    : 'border-gray-700 text-gray-400 hover:text-white'
                }
              >
                Active
              </Button>
              <Button
                variant={filterStatus === 'completed' ? 'default' : 'outline'}
                onClick={() => setFilterStatus('completed')}
                className={
                  filterStatus === 'completed'
                    ? 'bg-[#FF6B35] hover:bg-[#E55A2B] text-white'
                    : 'border-gray-700 text-gray-400 hover:text-white'
                }
              >
                Completed
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="flex justify-center py-8">
              <Loader className="w-8 h-8 text-[#FF6B35] animate-spin" />
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow className="border-gray-800 hover:bg-transparent">
                    <TableHead className="text-gray-400">Driver</TableHead>
                    <TableHead className="text-gray-400">Vehicle</TableHead>
                    <TableHead className="text-gray-400">Start Time</TableHead>
                    <TableHead className="text-gray-400">End Time</TableHead>
                    <TableHead className="text-gray-400">Status</TableHead>
                    <TableHead className="text-gray-400 text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredShifts.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={6} className="text-center py-8 text-gray-500">
                        No shifts found
                      </TableCell>
                    </TableRow>
                  ) : (
                    filteredShifts.map((shift) => (
                      <TableRow key={shift.id} className="border-gray-800">
                        <TableCell className="font-medium text-white">{shift.driver_name}</TableCell>
                        <TableCell className="text-gray-300">{shift.vehicle_plate}</TableCell>
                        <TableCell className="text-gray-300">
                          <div className="flex items-center gap-2">
                            <Clock className="w-4 h-4 text-gray-500" />
                            {format(new Date(shift.startTime), 'MMM dd, HH:mm')}
                          </div>
                        </TableCell>
                        <TableCell className="text-gray-300">
                          {shift.endTime ? (
                            format(new Date(shift.endTime), 'MMM dd, HH:mm')
                          ) : (
                            <span className="text-yellow-400">In progress</span>
                          )}
                        </TableCell>
                        <TableCell>
                          <Badge
                            className={
                              shift.status === 'active'
                                ? 'bg-green-950 text-green-400 border-green-900'
                                : 'bg-gray-800 text-gray-400 border-gray-700'
                            }
                          >
                            {shift.status}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center justify-end gap-2">
                            {shift.status === 'active' && (
                              <Button
                                variant="ghost"
                                size="sm"
                                className="text-gray-400 hover:text-red-400 h-8 px-2 text-xs"
                                onClick={() => {
                                  setSelectedShift(shift);
                                  setEndShiftDialog(true);
                                }}
                              >
                                End Shift
                              </Button>
                            )}
                          </div>
                        </TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      {/* End Shift Confirmation Dialog */}
      <AlertDialog open={endShiftDialog} onOpenChange={setEndShiftDialog}>
        <AlertDialogContent className="bg-[#161616] border-gray-800">
          <AlertDialogHeader>
            <AlertDialogTitle className="text-white">End Shift</AlertDialogTitle>
            <AlertDialogDescription className="text-gray-400">
              Are you sure you want to end the shift for {selectedShift?.driver_name}? This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <div className="flex gap-4">
            <AlertDialogCancel className="bg-gray-800 text-gray-300 hover:bg-gray-700">
              Cancel
            </AlertDialogCancel>
            <AlertDialogAction
              onClick={handleEndShift}
              className="bg-green-600 text-white hover:bg-green-700"
            >
              End Shift
            </AlertDialogAction>
          </div>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
