# TransLine Portal

## PWA notes

- Build: `cd portal && npm run build`
- Preview locally: `npm run preview` and open `http://localhost:4173/portal/`
- Install on iOS: Safari → Share → Add to Home Screen

The portal is deployed under `/portal/`, so assets, the manifest, and the service worker are configured with the `/portal/` base path.
