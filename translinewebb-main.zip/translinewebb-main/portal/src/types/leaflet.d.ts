export {};

declare global {
  interface Window {
    L: any;
  }

  const L: any;
}
