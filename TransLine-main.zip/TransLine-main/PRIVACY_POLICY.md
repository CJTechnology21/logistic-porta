# TransLine Driver App - Privacy Policy

**Last Updated:** January 14, 2026

## Introduction

TransLine ("we", "our", or "us") operates the TransLine Driver mobile application. This Privacy Policy explains how we collect, use, and protect your personal information.

## Information We Collect

### 1. Personal Information
- **Name and Contact Details**: Full name, email address, phone number
- **Account Information**: Login credentials, driver ID
- **Employment Information**: Shift records, vehicle assignments

### 2. Location Data
- **GPS Coordinates**: Real-time location during active shifts
- **Route Information**: Historical location data for completed shifts
- **Geofencing**: Entry/exit from designated areas

**Why We Collect Location Data:**
- Track shift routes for compliance and safety
- Verify shift completion and vehicle movements
- Optimize route planning and fleet management
- Provide emergency assistance if needed

**When We Collect Location:**
- Only during active shifts (after you start a shift)
- Stops automatically when you end your shift
- Requires your explicit permission

### 3. Device Information
- Device type and operating system
- Push notification tokens
- App version and settings

### 4. Operational Data
- **Shift Records**: Start/end times, odometer readings
- **Photos**: Odometer images, incident photos
- **Event Logs**: Fuel logs, break records, incident reports
- **Notes**: Driver-submitted operational notes

## How We Use Your Information

We use collected data to:
1. **Manage Shifts**: Track shift start/end, breaks, and compliance
2. **Fleet Operations**: Monitor vehicle usage and route optimization
3. **Safety & Compliance**: Ensure driver safety and regulatory compliance
4. **Communication**: Send operational alerts and notifications
5. **Record Keeping**: Maintain required employment and operational records
6. **Service Improvement**: Analyze app usage to improve functionality

## Data Storage and Security

- **Cloud Storage**: Data stored securely on Supabase (AWS infrastructure)
- **Encryption**: All data transmitted using industry-standard encryption (TLS/SSL)
- **Access Control**: Role-based access with row-level security policies
- **Retention**: Data retained as required by law and company policy

## Data Sharing

We do **NOT** sell your personal data. We may share data with:
- **Operations Team**: For shift management and fleet coordination
- **Legal Authorities**: When required by law or to protect safety
- **Service Providers**: Supabase (database), Expo (push notifications)

## Your Rights

You have the right to:
- **Access**: Request a copy of your personal data
- **Correction**: Update incorrect or incomplete information
- **Deletion**: Request deletion of your data (subject to legal requirements)
- **Opt-Out**: Disable location tracking or notifications (may limit app functionality)

**To Exercise Your Rights:**
Contact your fleet manager or email: privacy@transline.com

## Location Permissions

### iOS
- **When In Use**: Tracks location only when app is open
- **Always**: Enables background location tracking during shifts
- You can change permissions in: Settings > TransLine > Location

### Android
- **Precise Location**: Required for accurate shift tracking
- **Background Location**: Enables tracking during active shifts
- You can change permissions in: Settings > Apps > TransLine > Permissions

## Push Notifications

- **Operational Alerts**: Shift reminders, route changes, urgent messages
- **Opt-Out**: Disable in app settings or device notification settings
- Does not affect core app functionality

## Camera & Photos

- Used only to capture odometer readings and incident documentation
- Photos stored securely in company systems
- Not accessed for any other purpose

## Children's Privacy

This app is intended for employees aged 18 and over. We do not knowingly collect data from children under 18.

## Changes to This Policy

We may update this policy periodically. Significant changes will be communicated via:
- In-app notifications
- Email to registered drivers
- Updated "Last Updated" date in this document

## Data Deletion

To request deletion of your data:
1. Contact your fleet manager
2. Email privacy@transline.com
3. Include your name, driver ID, and email address

We will process requests within 30 days, subject to legal retention requirements.

## Contact Us

**TransLine Logistics**  
Email: privacy@transline.com  
Phone: [Your Company Phone]  
Address: [Your Company Address]

## Compliance

This app complies with:
- Australian Privacy Principles (APPs)
- General Data Protection Regulation (GDPR) where applicable
- California Consumer Privacy Act (CCPA) where applicable

## Consent

By using the TransLine Driver app, you consent to this Privacy Policy.
