// Login page for TransLine Admin Portal
import React, { useState } from 'react';
import { Navigate } from 'react-router';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/app/components/ui/button';
import { Input } from '@/app/components/ui/input';
import { Label } from '@/app/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/app/components/ui/card';
import { Alert, AlertDescription } from '@/app/components/ui/alert';
import { Truck, AlertCircle } from 'lucide-react';

export function LoginPage() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const { user, signIn } = useAuth();

  // Redirect if already logged in
  if (user) {
    return <Navigate to="/" replace />;
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      const { error } = await signIn(email, password);

      if (error) {
        // Parse Supabase error messages
        let errorMessage = 'Failed to sign in. Please check your credentials.';

        if (error.message) {
          if (error.message.includes('Invalid login credentials')) {
            errorMessage = 'Invalid email or password.';
          } else if (error.message.includes('Email not confirmed')) {
            errorMessage = 'Please confirm your email address.';
          } else {
            errorMessage = error.message;
          }
        }

        setError(errorMessage);
        setLoading(false);
      } else {
        // Success - navigation happens automatically via auth state change
      }
    } catch (err) {
      console.error('Sign in error:', err);
      setError('An unexpected error occurred. Please try again.');
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-[#0F0F0F] p-4">
      <div className="w-full max-w-md">
        <div className="flex flex-col items-center mb-8">
          <div className="w-16 h-16 bg-[#FF6B35] rounded-lg flex items-center justify-center mb-4">
            <Truck className="w-10 h-10 text-white" />
          </div>
          <h1 className="text-3xl font-bold text-white">TransLine Admin Portal</h1>
          <p className="text-gray-400 mt-2">Fleet Management System</p>
        </div>

        <Card className="bg-[#161616] border-gray-800">
          <CardHeader>
            <CardTitle className="text-white text-2xl">Sign In</CardTitle>
            <CardDescription className="text-gray-400">
              Enter your credentials to access the admin portal
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              {error && (
                <Alert variant="destructive" className="bg-red-950 border-red-900">
                  <AlertCircle className="h-4 w-4" />
                  <AlertDescription>{error}</AlertDescription>
                </Alert>
              )}

              <div className="space-y-2">
                <Label htmlFor="email" className="text-white">Email</Label>
                <Input
                  id="email"
                  type="email"
                  placeholder="admin@transline.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                  className="bg-[#0F0F0F] border-gray-700 text-white placeholder:text-gray-500"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="password" className="text-white">Password</Label>
                <Input
                  id="password"
                  type="password"
                  placeholder="••••••••"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                  className="bg-[#0F0F0F] border-gray-700 text-white placeholder:text-gray-500"
                />
              </div>

              <div className="bg-[#0F0F0F] border border-gray-800 rounded-lg p-3">
                <p className="text-xs text-gray-400">
                  <strong className="text-gray-300">Development Mode:</strong> Use test credentials
                </p>
                <p className="text-xs text-gray-500 mt-1">
                  Email: admin@test.com | Password: admin123
                </p>
              </div>

              <Button
                type="submit"
                disabled={loading}
                className="w-full bg-[#FF6B35] hover:bg-[#E55A2B] text-white font-medium"
              >
                {loading ? 'Signing in...' : 'Sign In'}
              </Button>
            </form>
          </CardContent>
        </Card>

        <p className="text-center text-xs text-gray-500 mt-6">
          TransLine Logistics © 2026. Admin access only.
        </p>
      </div>
    </div>
  );
}
